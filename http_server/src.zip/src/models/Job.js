class Job {
  constructor(job_id, code, path ) {
    this.job_id = job_id;
    this.code = code;
    this.path = path;
  }
}
module.exports = Job;